var searchData=
[
  ['beginrecordingsession',['BeginRecordingSession',['../classi_vid_cap_pro.html#a91b185d1f72ada556659e670beafe972',1,'iVidCapPro']]]
];
