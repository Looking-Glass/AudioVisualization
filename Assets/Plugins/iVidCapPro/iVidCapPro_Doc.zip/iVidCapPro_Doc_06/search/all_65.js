var searchData=
[
  ['endrecordingsession',['EndRecordingSession',['../classi_vid_cap_pro.html#abaf2d2a9c22c89fe9ac05717d5580aa9',1,'iVidCapPro']]],
  ['endrecordingsessionwithaudiofile',['EndRecordingSessionWithAudioFile',['../classi_vid_cap_pro.html#aeca7a4dee43b1716b89d79ed9f4fb49a',1,'iVidCapPro']]]
];
