var searchData=
[
  ['sessioncompletedelegate',['SessionCompleteDelegate',['../classi_vid_cap_pro.html#a174d7135ffe2fcfc1090fcff4c4de4ec',1,'iVidCapPro']]],
  ['sessionerrordelegate',['SessionErrorDelegate',['../classi_vid_cap_pro.html#a43571a3f899e307407e6f56327b51b8e',1,'iVidCapPro']]],
  ['setdebug',['SetDebug',['../classi_vid_cap_pro.html#a16a23e121921ae9acb5b5a91ef9199df',1,'iVidCapPro']]]
];
