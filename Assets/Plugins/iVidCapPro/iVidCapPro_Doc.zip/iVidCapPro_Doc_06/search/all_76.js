var searchData=
[
  ['videodisposition',['VideoDisposition',['../classi_vid_cap_pro.html#a1a34e69d64f2a271fba8a17d0406172c',1,'iVidCapPro']]]
];
