var searchData=
[
  ['log',['Log',['../classi_vid_cap_pro.html#a0fed135bafcb484d15e50ab0dfec5c89',1,'iVidCapPro']]]
];
