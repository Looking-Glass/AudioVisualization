var searchData=
[
  ['getsessionstatus',['GetSessionStatus',['../classi_vid_cap_pro.html#a16f06d264e0515c2911942f56ba0b720',1,'iVidCapPro']]]
];
