var searchData=
[
  ['registersessioncompletedelegate',['RegisterSessionCompleteDelegate',['../classi_vid_cap_pro.html#a6c11d6cc416e6f1017b49fa1b33d8b1b',1,'iVidCapPro']]],
  ['registersessionerrordelegate',['RegisterSessionErrorDelegate',['../classi_vid_cap_pro.html#a464de3bd847b16c3885e988417dbe6e5',1,'iVidCapPro']]]
];
