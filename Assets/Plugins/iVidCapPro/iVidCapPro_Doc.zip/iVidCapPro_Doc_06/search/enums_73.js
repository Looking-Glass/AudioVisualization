var searchData=
[
  ['sessionstatuscode',['SessionStatusCode',['../classi_vid_cap_pro.html#a226650d02b62092e3e57efe467f790f1',1,'iVidCapPro']]]
];
