var searchData=
[
  ['configuregammasetting',['ConfigureGammaSetting',['../classi_vid_cap_pro.html#a41b4f802b8ced7123b753009ea63a6fc',1,'iVidCapPro']]],
  ['configurevideosettings',['ConfigureVideoSettings',['../classi_vid_cap_pro.html#a793732730916c2043a8af803410a0058',1,'iVidCapPro']]]
];
