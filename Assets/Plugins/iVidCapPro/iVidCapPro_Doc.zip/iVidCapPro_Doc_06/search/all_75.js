var searchData=
[
  ['unregistersessioncompletedelegate',['UnregisterSessionCompleteDelegate',['../classi_vid_cap_pro.html#a55823f07baa9abdcfd992d86828fedbf',1,'iVidCapPro']]],
  ['unregistersessionerrordelegate',['UnregisterSessionErrorDelegate',['../classi_vid_cap_pro.html#af0cad2dde8023764ab2d0b8914ce06b1',1,'iVidCapPro']]]
];
