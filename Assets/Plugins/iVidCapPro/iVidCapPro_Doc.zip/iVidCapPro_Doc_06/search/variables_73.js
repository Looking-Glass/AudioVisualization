var searchData=
[
  ['saveaudio',['saveAudio',['../classi_vid_cap_pro.html#a8ae11e3d94743eae075d7dbfb16775a0',1,'iVidCapPro']]]
];
