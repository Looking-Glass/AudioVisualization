var searchData=
[
  ['gain',['gain',['../classi_vid_cap_pro_audio.html#ae2401c71967ad6f36bcf2ded9b7c655e',1,'iVidCapProAudio']]]
];
