var searchData=
[
  ['captureaudio',['CaptureAudio',['../classi_vid_cap_pro.html#a8a1282f1fdb6ced6c3ea9b447a9e4a58',1,'iVidCapPro']]],
  ['capturecameratype',['CaptureCameraType',['../classi_vid_cap_pro.html#a7673b0d26467d813f4a9cc2842996578',1,'iVidCapPro']]],
  ['captureframeratelock',['CaptureFramerateLock',['../classi_vid_cap_pro.html#a1652a6c7e6f406f22fab8e45910cc2bc',1,'iVidCapPro']]]
];
